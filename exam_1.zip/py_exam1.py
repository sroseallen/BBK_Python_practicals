def division(number1, number2):
    """
        Question 1
        Complete the function so that it returns the division of the first argument by the second.
        
        Example use: division(5.45, 1.09)
        Example output: 5.0
    """
    # Complete the function body below to answer question 1
    result = round(number1 / number2, 1)

    return result


def count_motif(filename="multi_seqs.txt", motif="LL"):
    """
        Question 2
        The file with the filename given as an argument contains several amino-acid sequences, one per line.
        Write a function that returns the number of sequences containing the motif 'LL' in file `multi_seqs.txt`.
        **Note:** You can assume that every line in `multi_seqs.txt` contains a single sequence.
        
        Example use: count_motif(filename="multi_seqs.txt", motif="E")
        Example output: 41
    """
    # Complete the function body below to answer question 2
    number_of_seqs = 0

    with open (filename, 'r') as file:
        for seq in file:
            if motif in seq:
                number_of_seqs += 1  
    
    return number_of_seqs

def write_fasta(filename="pdb_chains2.txt"):
    """
        Question 3
        The file with the filename given as an argument contains amino-acid identifiers and sequences in the following format:
        1A1Q:A PITAYSQQTRGLLGCIITSLTGRD
        1A1Q:B PITAYSQGLLGCIITSLT
        1DFK:A SDPDFQYLAVDFD
        ...
        
        Taking the first entry as an example (all on a single line in the file), 1A1Q is a PDB code,
        the A after the colon (:) is a chain identifier, then (after a space) there is the sequence.

        Write a function that reads in this file and returns each sequence in the following format:

        >1a1qA 
        PITAYSQQTRGLLGCIITSLTGRDK...

        Note that:
            - The first line contains the PDB code plus chain identifier, the second line contains the sequence
            - The PDB code is preceded by a greater-than sign (>)
            - The PDB code is in lowercase
            - There is no gap or colon in front of the chain identifier (which remains in uppercase)
            - The whole sequence is on a separate line.
            
        Return a list of strings containing the whole text
        Example use: write_fasta(filename="pdb_chains2_short.txt") -> the file contains a single line "1A1Q:A PITAY"
        Example output: [">1a1qA", "PITAY"]
    """
    # Complete the function body below to answer question 3
    lines = []
    
    with open (filename, 'r') as file:

        for line in file:
            pdb_code = line[:4].lower() 
            chain_id = line[5]
            lines.append(str(">" + pdb_code + chain_id)) 
            lines.append(str(line[7:-1])) # removes final character in sliced sequence as this is \n (new line character)

    return lines

def genus_stats(filename="species1.txt"):
    """
        Write a script that returns the number of unique genus, as well as the average number of species per genus, in a file such as species1.txt, containing one specie per line, with the genus and species name separated by a space.
        genus_stats()
        Example use: genus_stats("../data/species2.txt")
        Example output: (140, 1.7857)
    """
    # Complete the function body below to answer question 4
    unique_genus = set()
    
    with open (filename, 'r') as file:
        organisms = file.read().split() # reads into a list in the format ["genus", "species", "genus", "species"...]
        organisms = organisms[::2] # removes the species names from the list
    
        number_of_species = len(organisms) # total no. organisms (species) read into the list
    
        for genus in organisms:
            unique_genus.update(organisms) # A genus from the list is only added if it is not already in the set, therefore makes a unique set of genus names.

    number_unique_genus = len(unique_genus)
    avg_species_per_genus = round(number_of_species / number_unique_genus, 4)
    
    return number_unique_genus, avg_species_per_genus

if __name__ == '__main__':
    print(division(-5, 3))
    print(count_motif(filename='../data/multi_seqs.txt', motif="LL"))
    print(write_fasta(filename='../data/pdb_chains2.txt'))
    print(genus_stats(filename='../data/species1.txt'))