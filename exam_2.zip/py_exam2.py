import numpy as np
def generate_number_list(last_number: int = 21) -> np.array:
    """ 
    Generates a numpy array of evenly spaced numbers, with a range from 3 up to the defined last_number (21 by default)
    """
    array = np.linspace(3, last_number, 7)
        
    return array


from typing import TextIO
def lex_sort_file(filename: TextIO="../data/multi_seqs.txt") -> list:
    """
    Opens a file of sequences and sorts them alphabetically.
    """
    with open (filename, 'r') as file:
        listed = list(file.read().splitlines()) # reads in line by line, removes \n character
        listed.sort()
        
    return listed


def top_lysine_stats(filename: TextIO = "../data/multi_seqs.txt") -> str:
    """
    Reads in a file of sequences, and outputs the string with the highest lysine residue percentage.
    Outputs two pieces of data: the percentage, and the string itself.

    """
    with open (filename, 'r') as file:
        all_seqs = list(file.read().splitlines()) # reads in line by line, removes \n character
        
        max_percent = 0 # defines initial values for the maximum percent and string
        max_string = ""
        
        for seq in all_seqs:
            seq_percent = (seq.count("K") / len(seq)) * 100 # counts lysine in each sequence, then converts to percentage
            if seq_percent > max_percent:
                max_percent = seq_percent # overwrites and stores current sequence data if the percentage of lysine is higher
                max_string = seq
                
    return max_percent, max_string


import numpy as np
def avg_lysine_stats(filename: TextIO = "../data/multi_seqs.txt") -> int:
    """
    Calculates the mean and median number of lysine residues in a list of protein sequences.
    Outputs two results as such:
        (mean, median)
    """
    with open (filename, 'r') as file:
        all_seqs = list(file.read().splitlines()) # reads in line by line, removes \n character
    
    lysine_count = []
    for seq in all_seqs:
        lysine_count.append(seq.count("K")) # for each sequence, adds the number of lysine residues to the lysine_count list
        
    lysine_calcs = np.array(lysine_count) # converts list of lysine residues to numpy array so mean and median can be calculated using the numpy package.
    lysine_mean = lysine_calcs.mean()
    lysine_median = np.median(lysine_calcs)
    
    return (lysine_mean, lysine_median)


import matplotlib.pyplot as plt
def plot_lysine_stats(filename: TextIO = "../data/multi_seqs.txt") -> plt.Axes:
    """Question 3c
        Wrte a function that plot the distribution of lysine counts, in the sequences from file `multi_seqs.txt`.

        Example use: plot_lysine_stats()
        Example output:  <plot of the lysine count distribution>
    """
    with open (filename, 'r') as file:
        all_seqs = list(file.read().splitlines()) # reads in line by line, removes \n character
    
    # generates a list of lysine count per sequence
    lysine_count = []
    for seq in all_seqs:
        lysine_count.append(seq.count("K")) 
        
    # plots the distribution of lysine across the sequences as a histogram
    fig, axs = plt.subplots()
    axs.hist(lysine_count, bins = 10, color = "SeaGreen") # creates histogram (sorted into 10 bins as maximum value of lysine in sequence is 10 for this set)
    axs.set_title("Distribution of Lysine residues in multi_seqs file") # plot title
    axs.set_xlabel("Number of residues") # plot x axis
    axs.set_ylabel("Number of sequences") # plot y axis
    plt.show()
    return


def translate_dna(codons_fname: TextIO = '../data/codons.txt', dna_fname: TextIO ='../data/dna.txt') -> list:
    """
    Scans through a DNA sequence until a start codon is reached, then translates to protein sequence until a stop codon is reached.
    Each of these translated 'fragments' are added to a final list output which gives all translated fragments.
    
    Note: Differing reading frames are not accounted for; reading frame starts from index 0 only.
    """
    # read in DNA sequence in one single string
    with open (dna_fname, 'r') as file_dna:
        seq = file_dna.read().split()
        seq = "".join(seq).rstrip()
    # read in codon table
    with open (codons_fname, 'r') as file_codons:
        codons = file_codons.read().splitlines()

    # define starting values
    current_index = 3
    current_triplet = "".join(seq[0 : 3]) # retrieves first 3 amino acids in sequence
    current_acid = ""
    reading_frame_open = 0 # marker for if the sequence should be translated (0 if closed/not translating, 1 if open/translating)
    prot_fragment = "" # the current fragment being translated
    prot_full_seq = []  # the full list of all translated fragments

    for base in seq:
        if current_index > len(seq): # prevents null values being added to the end of the prot_fragment list
            break
        else:
            # lookup the triplet nucleotide in codon table, retrieve translated amino acid as current_acid
            for codon in codons:
                if current_triplet in codon:
                    current_acid = codon.split(":")[0]

            # if codon is a start codon, open the reading frame if it was closed, otherwise the start codon is mid-sequence and is added to the current protein fragment
            if current_acid == "START":
                if reading_frame_open == 0:
                    reading_frame_open = 1 
                else:
                    prot_fragment += "M"
        
            # if codon is a stop codon, close the reading frame, store the current fragment, and continue to next triplet nucleotide
            elif current_acid == "STOP":
                if reading_frame_open == 1:
                    prot_full_seq.append (prot_fragment) # only adds current fragment if the reading frame was open (otherwise will add null values to the full list)
                    prot_fragment = "" # empties previous fragment ready for the next translation
                reading_frame_open = 0 
                
            # if codon is not a start or stop, ensure reading frame is open, and add amino acid to current protein fragment
            elif reading_frame_open == 1:
                prot_fragment += current_acid
            
            current_index += 3
            current_triplet = "".join(seq[current_index - 3 : current_index]) # slices the next three characters in the seq string
        
    return prot_full_seq


def longest_translatable_sequence(codons_fname: TextIO = '../data/codons.txt', dna_fname: TextIO ='../data/dna.txt') -> int:
    """
    Scans through a DNA sequence until a start codon is reached, then translates to protein sequence until a stop codon is reached.
    Function checks all three forward reading frames for the longest continuous translated fragment, and outputs the length of the DNA sequence corresponding to that fragment.
    DNA Sequence length includes the start codon 'ATG'.
    """
    # read in DNA sequence in one single string
    with open (dna_fname, 'r') as file_dna:
        seq = file_dna.read().split()
        seq = "".join(seq).rstrip()
    # read in codon table
    with open (codons_fname, 'r') as file_codons:
        codons = file_codons.read().splitlines()

    # define starting values
    current_acid = ""
    reading_frame_open = 0 # marker for if the sequence should be translated (0 if closed/not translating, 1 if open/translating)
    prot_fragment = "" # the current output protein fragment
    dna_fragment = "" # the DNA sequence currently being translated
    
    reading_frame = 0 # tracks which reading frame is in use: starting from index 0, 1 or 2
    dna_prot_dict = {} # a dictionary to track which DNA sequence corresponds to which protein fragment
    
    while reading_frame < 3:
        current_index = reading_frame + 3 # starts at reading frame 0 (index 0 in sequence)
        current_triplet = "".join(seq[reading_frame : reading_frame + 3]) # retrieves first 3 amino acids in current reading frame
        
        for base in seq:
            if current_index > len(seq): # prevents null values being added to the end of the prot_fragment list
                break
            else:
                # lookup the triplet nucleotide in codon table, retrieve translated amino acid as current_acid
                for codon in codons:
                    if current_triplet in codon:
                        current_acid = codon.split(":")[0]

                # if codon is a start codon, open the reading frame (start codon is not removed in this scenario, retains ATG/M in nucleotide/protein sequence length)
                if current_acid == "START":
                    reading_frame_open = 1 
                    prot_fragment += "M"
                    dna_fragment += current_triplet
                        
                # if codon is a stop codon, close the reading frame, store the current fragment, and continue to next triplet nucleotide
                elif current_acid == "STOP":
                    if reading_frame_open == 1:
                        dna_prot_dict[dna_fragment] = prot_fragment # only adds fragments to dictionary if the reading frame was open (or code adds null values to dictionary)
                        dna_fragment = ""  # empties previous fragments ready for the next translation
                        prot_fragment = "" 
                    reading_frame_open = 0 
                
                # if codon is not a start or stop, ensure reading frame is open, and add amino acid to current protein fragment
                elif reading_frame_open == 1:
                    prot_fragment += current_acid
                    dna_fragment += current_triplet
            
                current_index += 3
                current_triplet = "".join(seq[current_index - 3 : current_index]) # slices the next three characters in the seq string
                
        reading_frame += 1 # moves to the next reading frame
    
    # identify longest fragment and return
    return len(max(dna_prot_dict, key = len)) 


if __name__ == '__main__':
    print(generate_number_list())
    print(lex_sort_file(filename='../data/multi_seqs.txt'))
    print(top_lysine_stats(filename='../data/multi_seqs.txt'))
    print(avg_lysine_stats(filename='../data/multi_seqs.txt'))
    print(plot_lysine_stats(filename='../data/multi_seqs.txt'))
    print(translate_dna(codons_fname='../data/codons.txt', dna_fname='../data/dna.txt'))
    print(longest_translatable_sequence(codons_fname='../data/codons.txt', dna_fname='../data/dna.txt'))