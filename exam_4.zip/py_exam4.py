"""
# Exam 04
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage
from Bio import AlignIO
import pandas as pd
import sqlite3
"""
## Q1: git repository

## NB: I've run these commands in the JupyterHub notebook to confirm they work!

!git init .
with open("./file1.py", 'w') as file:
    file.write("Test")
with open("./README.md", 'w') as readme:
    readme.write("Test")

!git config --global user.name "Sophie Allen"
!git config --global user.email "sallen10@student.bbk.ac.uk"

!git add file1.py
!git add README.md

!git commit -m "(Sophie A) Created file1 and the README file"

!git log
"""

"""
## Q2: center of mass in a volume
"""
def load_volume_data(
    filename: str = "../data/1CS4.npz",
    arrayname: str = "map_1CS4"):
    # load the 3d volume as a numpy array
    volume = np.load(filename)[arrayname]
    return volume

def plot_volume_projection(
    volume: np.array):
    fig, axes = plt.subplots(1,2)
    # display the center slice of the volume
    axes[0].imshow(volume[15])
    # display the x-axis projection of the volume
    axes[1].imshow(volume.sum(axis=0))
    plt.show()

def compute_volume_COM(volume: np.array) -> tuple:
    """
    Finds the maximum volume in the 3D object, given as a set of nested arrays, and returns the exact coordinates of this
    """
    center_of_mass = ndimage.center_of_mass(volume)
        
    center_of_mass = np.array(center_of_mass)
    return tuple(center_of_mass) # returns the coordinates of the max volume in the 3D array

def test_compute_volume_COM():
    """
    Passes if compute_volume_COM returns the coordinates (2, 1, 1) - the location of the only non-zero value in the test 3D array
    """
    test_array = np.array([[[0, 0, 0],
                           [0, 0, 0],
                           [0, 0, 0]],
                          [[0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0]],
                          [[0, 0, 0],
                          [0, 1, 0],
                          [0, 0, 0]]])
    assert(compute_volume_COM(test_array) == (2, 1, 1))

"""
## Q3: finding motifs, distribution
"""
def get_motif_counts_df(
    aligned_filename: str = "../data/hAPP.clustal",
    motifs: list = ["LL", "EE", "W"],
    num_chars: int = None) -> pd.DataFrame:
    """
    For each sequence in a clustal alignment, finds the number of each pre-determined motif and records in a pandas dataframe.
    Arguments: 
    aligned_filename: Path to a clustal file
    motifs: List of strings to count in the aligned sequences
    num_chars: Optional, specifies the number of characters to select and count from the start of the sequences
    """
    # Reads in the alignment and converts motif list to a dictionary (one empty list per motif)
    alignment = AlignIO.read(aligned_filename, "clustal")
    # slices and selects the first few characters in the sequences if specified
    if num_chars is not None:
        alignment = alignment[:, :num_chars]
    motifs_df = {m:[] for m in motifs} # generic to allow more/less motifs to be searched and counted
    
    # loops through sequences and adds the total count of each motif to the empty list defined above
    for a in alignment:
        for m in motifs:
            motifs_df[m].append(a.seq.count(m))
    
    # assigns dictionary to a dataframe, one row = data for one sequence
    df = pd.DataFrame(data=motifs_df)
    return df

def test_get_motif_counts_df(
    aligned_filename: str = "../data/hAPP.clustal"):
    """
    Passes if the counts for the first 12 characters in the alignment match the numbers in test_df (manually counted for first 12 characters in each sequence)
    """
    # Runs the motif_count function with the optional argument to slice and count the first 12 characters of the alignment
    df = get_motif_counts_df(aligned_filename, num_chars=12)

    # Pre-determined manual counts for the first 10 characters of the alignment
    test_df = pd.DataFrame({
        "LL":[2,2,2,2,2,2,1,2,2,2,2,2],
        "EE":[0]*12,
        "W":[0]*12,
    })
    assert  df.equals(test_df) # checks if the get_motif_counts_df output for the sliced alignments matches the expected test_df output.

def get_median(df: pd.DataFrame) -> list:
    """    
    Returns a dictionary of the motif columns (key) and the average occurance of the motif per sequence (value).
    """
    # adds the average for each column to the average_dict dictionary
    list = []
    for column in df:
        data = df[column]
        list.append(data.median())
    return list

"""
## Q4 EMDB data, pandas
"""
def find_matching_entries(
    database_name: str = "../data/emdb.db",
    search_term: str = "Life") -> pd.DataFrame:
    """
    A search function for finding virus-related entries in EMDB.
    Returns a pandas dataframe containing the id, title, and year of matching entries in descending order.
    """
    # 1: Selects the data from the database
    search_con = sqlite3.connect(database_name)
    search_cur = search_con.cursor()

    # 2: Filters the database for just entries containing the search term (and sorts in descending order)
    search_res = search_cur.execute(f"SELECT id, title, date FROM entries WHERE title LIKE '%{search_term}%' ORDER BY date DESC")
    search_fullresults = search_res.fetchall()

    # 3: Makes a pandas dataframe from the filtered data
    search_df = pd.DataFrame(
    {
    "id":[i[0] for i in search_fullresults],
    "title":[i[1] for i in search_fullresults],
    "date":[i[2] for i in search_fullresults]
    })

    return search_df

def test_find_matching_entries(
    database_name: str = "../data/emdb.db"):
    """
    Passes if the search term ZZZXYZ provides 0 entries in the SQL database
    """
    test_df = find_matching_entries(database_name, search_term = "ZZZZXYZ")
    assert len(test_df.index) == 0