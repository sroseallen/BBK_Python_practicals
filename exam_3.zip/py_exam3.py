import pandas as pd # Question 1
import numpy as np # Question 1
import networkx as nx # Questions 2a, 2b, 3a, 3b, 4
import itertools # Question 3a

## Question 1
def compute_properties(dna_adj_file: str = "../data/dna_adj.csv") -> int:
    """
    Function to produce a set of summary statistics about the dna_adj file, including:
        Q1a: The number of elements containing no value (0.0)
        Q1b: The 98th percentile of all values
        Q1c: The sum total of values for any row starting with 'TT'
    """
    df = pd.read_csv(dna_adj_file, index_col=0)

    Q1a = 0
    for i in df.to_numpy().flatten():
        if i == 0:
            Q1a += 1

    Q1b = np.percentile(df.to_numpy().flatten(), 98)

    Q1c = 0
    for row in df.index:
        if row.startswith("TT"):
            Q1c += sum(df.xs(row, 0))
            
    return Q1a, Q1b, Q1c

## Question 2a
class GraphChecker:
    """
    Class which provides methods for QA of a Networkx graph object.
    
    ---- Object Attributes ----
    graph (str): GraphChecker object identifier

    ---- Object Methods ---- 
    __init__(self, graph: nx.Graph)
    check(self)
    check_error(self)
    """
    def __init__ (self, graph: nx.Graph) -> 'GraphChecker':
        """ Creates instance of the GraphChecker object, including the .graph attribute for the object """
        self.graph = graph
    
    def check(self: 'GraphChecker') -> bool:
        """ Checks for nodes - if there are any nodes present, will return True, otherwise will fail and return False. """
        if nx.number_of_nodes(self.graph) > 0:
            return True
        
    def check_error(self: 'GraphChecker') -> int:
        """ 
        Empty graph error checker.
        Tries to divide 2 by the number of nodes. If graph is empty (no nodes), will raise a ZeroDivisionError, handled by the 'except' clause.
        """
        try:
            2 / nx.number_of_nodes(self.graph)
        except ZeroDivisionError:
            print ("Number of nodes:", nx.number_of_nodes(self.graph))
            raise AttributeError("Graph is empty, please ensure your graph contains data.")
        return
    
## The code here should run, assuming you wrote the class above properly, and named it GraphChecker
def test_gc():
    g = nx.Graph()
    gc = GraphChecker(g)
    if gc.check():
        print("This graph has nodes!")
    else:
        print("Warning! This graph has no nodes!")

## Question 2b
def test_gc_ce() -> int:
    """
    Error checking function - will provide an integer if the graph contains nodes, otherwise will raise an error that the graph contains no data.
    """
    g = GraphChecker(nx.empty_graph())
    return g.check_error() 

## Question 3a
def create_db_graph(k: int=3) -> nx.DiGraph:
    """
    Creates a De Brujin graph which contains:
        a) All possible node combinations of 'k' length from the bases ATGC
        b) All possible directed edges between these nodes where the final two bases of one node match the first two bases of the second node.
    """
    def cartesian_product(letter: str="ATGC") -> str:
        """
        Iterates through all possible combinations of the provided 'letter' argument string for sequences of length 'k', eg:
            letter: "ABC"
            k: 2
            Iterations: "AA", "AB", "AC", "BA", "BB", "BC", "CA", "CB", "CC"
        """
        yield from itertools.product(*([letter] * k)) 

    # instantiate graph and add all possible kmer nodes generated from ATGC bases
    g = nx.DiGraph() # directed graph, includes self-loops
    for x in cartesian_product():
        g.add_node(''.join(x))

    for node in g.nodes():
        end = node[1:] # identifies the final k characters in the node label (kmer)
        for other_node in filter(lambda n: n[:-1] == end, g.nodes()):
            g.add_edge(node, other_node, count=0) # adds counts as an attribute for later
            
    return g 
# Note: Gradescope didn't accept matplotlib as a suitable package, but please check my JuptyerHub notebook if the drawn graph is required!

## Question 3b
def max_edge_count(g: nx.Graph, dna_file: str="../data/dna.txt") -> tuple:
    """
    For all overlapping k-mers in a sequence, finds the most common transition between kmers and returns the maximum count and the overlapping kmers involved.
    """
    # read in file with DNA sequence
    with open (dna_file, 'r') as f:
        seq = f.read().splitlines()
        seq = "".join(seq)
    
    # split each sequence in this file into k-mers of 3  
        kmers = [seq[i:i+3] for i in range(0, len(seq), 1)] # 1 being the number of positions i moves for each iteration in the loop; enables the overlap in kmers
        for i, k in enumerate(kmers):
            if len(k) != 3:
                del(kmers[i:]) # removes 'kmers' which are shorter than the defined kmer length

    # count number of 3-mers
    tot_kmer = len(kmers)

    # walk through the kmers in order, and for each transition, add 1 to that edge until the whole sequence is done
    for i, k in enumerate(kmers[0:(tot_kmer-1)]): # using tot_kmer-1 prevents index error
        kmer_1 = kmers[i]
        kmer_2 = kmers[i+1]
        g[kmer_1][kmer_2]["count"] += 1 # stores count of transitions logged as edge weight
    edges = g.edges.data("count", default=0)

    # find the largest edge count and the start/stop kmers
    max_count = 0
    for i in edges:
        if i[2] > max_count:
            max_count = i[2]
            max_nodes = (i[0], i[1])

    return max_nodes, max_count

## Question 4
def find_dbg_max_k(penguinpox_file: str="../data/penguinpox.fasta") -> tuple:
    """
    Finds the maximum lemgth kmer that can be used and still produce an edge count which is more than 1 for the .fasta file entered.
    """
    # read in .fasta file
    with open (penguinpox_file, 'r') as f:
        penguin_file = f.read().splitlines()
        del(penguin_file[0]) # removes fasta header
        penguin_file = "".join(penguin_file)

    kmer_length = 1 # initial kmer value
    current_max_count = 100 # default max_count to start loop

    # loop through increasing values for 'i' (kmer length) until the largest k value where at least 1 edge is >1 is reached.
    while current_max_count > 1:
        kmer_length += 1

        # split sequence into kmers
        kmers = [penguin_file[i:i+kmer_length] for i in range(0, len(penguin_file), 1)] # 1 being the number of positions i moves for each iteration in the loop; enables the overlap in kmers
        for i, k in enumerate(kmers):
            if len(k) != kmer_length:
                del(kmers[i:]) # removes any 'kmers' which are shorter than the defined kmer length
        
        # generate De Bruijn graph for the kmers
        g = nx.DiGraph()
        ending_kmers = {}

        # create nodes, identifies the first k characters in each node, and adds to a dictionary
        for k in kmers:
            g.add_node(k)
            start = k[:-1]
            if start not in ending_kmers:
                ending_kmers[start] = []
            ending_kmers[start].append(k)

        # create edges by checking if the final k characters in a given node matches any node in the dictionary
        for node in g.nodes():
            end = node[1:]
            if end in ending_kmers:
                for node_2 in ending_kmers[end]:
                    g.add_edge(node, node_2, count=0)

        # find the max edge count
        tot_kmer = len(kmers)

        for i, k in enumerate(kmers[0:(tot_kmer-1)]): # using tot_kmer-1 prevents index error
            kmer_1 = kmers[i]
            kmer_2 = kmers[i+1]
            g[kmer_1][kmer_2]["count"] += 1 # adds a value to edge attribute count if the transition is seen between nodes
        edges = g.edges.data("count", default=0) # saves all edge counts with their start/end nodes as a list of tuples.

        # find the largest edge count and the start/stop kmers
        current_max_count = 0
        for i in edges:
            if i[2] > current_max_count:
                current_max_count = i[2]
                current_max_nodes = (i[0], i[1])
        if current_max_count > 1:
            prev_max_nodes = current_max_nodes # saves the current max count and nodes for the next loop
            prev_max_count = current_max_count
        else:
            break
    return kmer_length, prev_max_nodes, prev_max_count # once the max count reaches 1, returns values from previous loop where max count was more than 1.

if __name__ == '__main__':
    print(compute_properties(dna_adj_file="../data/dna_adj.csv"))
    test_gc()
    g = create_db_graph(k=3)
    print(max_edge_count(g, dna_file="../data/dna.txt"))
    print(find_dbg_max_k(penguinpox_file="../data/penguinpox.fasta"))